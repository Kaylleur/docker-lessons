my_name = "Foo Bar"
print("Hello and welcome " + my_name + "!")
